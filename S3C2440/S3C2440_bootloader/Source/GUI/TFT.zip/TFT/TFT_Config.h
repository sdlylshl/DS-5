#ifndef _TFT_Config_H_
#define _TFT_Config_H_

/*
 *��ɫ����
 */
//���ڶ���ʵ����ʾ�ߴ� 
#define TFT_HIGHT 	(640)
#define TFT_WIDTH 	(480)

//RGB ��ռ��16λ R[15..11] G[10..5] B[4..0]
#define BLUE          0xFF0000
#define GREEN         0x00FF00
#define RED           0x0000FF
#define CYAN          0xFFFF00
#define MAGENTA       0xFF00FF
#define YELLOW        0x00FFFF
#define LIGHTBLUE     0xFF8080
#define LIGHTGREEN    0x80FF80
#define LIGHTRED      0x8080FF
#define LIGHTCYAN     0xFFFF80
#define LIGHTMAGENTA  0xFF80FF
#define LIGHTYELLOW   0x80FFFF
#define DARKBLUE      0x800000
#define DARKGREEN     0x008000
#define DARKRED       0x000080
#define DARKCYAN      0x808000
#define DARKMAGENTA   0x800080
#define DARKYELLOW    0x008080
#define WHITE         0xFFFFFF
#define LIGHTGRAY     0xD3D3D3
#define GRAY          0x808080
#define DARKGRAY      0x404040
#define BLACK         0x000000

#define BROWN         0x2A2AA5

#endif /*_TFT_Config_H_*/ 