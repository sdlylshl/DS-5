#ifndef _TFT_API_H_
#define _TFT_API_H_
void BrushBackground(U16 Bcolor);
void CleanScreen(void);
void DrawPixel(U32 x,U32 y,U16 Fcolor);
void Draw_Y_Line(U32 x,U32 y_begin,U32 y_end,U16 Fcolor);
void Draw_X_Line(U32 x_begin,U32 x_end,U32 y,U16 Fcolor);
void DrawSquare(U32 x_begin,U32 x_end,U32 y_begin,U32 y_end,U32 mode,U16 Fcolor);
void DrawCircle(U32 x,U32 y,U32 r,U32 mode,U16 Fcolor);
void DisplayImage(U32 x,U32 y,U32 iWidth,U32 iHeight,U8 bmp[]);
void Write_8x16_ASCII(U32 x,U32 y,const U8 ch[],U16 Fcolor);
void Write_16x16_Hanzi(U32 x,U32 y,const U8 ch[],U16 Fcolor);
void WriteChar(U32 x,U32 y,U8 ch,U16 Fcolor);
void WriteOneChar(U32 x,U32 y,U8 ch,U16 Fcolor);
void Write_ASCII_String(U32 x,U32 y,U8 *str,U16 Fcolor);
void Write_Hanzi_String(U32 x,U32 y,U8 *str,U16 Fcolor);
void Write_Mix_String(U32 x,U32 y,U8 str[],U16 Fcolor);
void TFT_Test(void);
#endif /* _TFT_API_H_*/ 